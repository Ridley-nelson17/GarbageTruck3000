# compile
javac -classpath .:classes:/opt/pi4j/lib/'*' -d . Pi4jExample.java

# run
sudo java -classpath .:classes:/opt/pi4j/lib/'*' Pi4jExample
