# UbuntuScripts (Beta Expirament Testing 1)
Random scripts for Ubuntu Desktop or other Linux based Environments I use.


## Basics
to boot usb from macbook hold down option while starting up then select the boot device
