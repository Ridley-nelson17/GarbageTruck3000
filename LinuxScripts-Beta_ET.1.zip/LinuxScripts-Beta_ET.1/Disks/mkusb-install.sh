sudo add-apt-repository universe  # only for standard Ubuntu
sudo apt-get install mkusb mkusb-nox usb-pack-efi
